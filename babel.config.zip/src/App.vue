<template>
  <v-app>
    <v-main>
      <AbbiFront/>
    </v-main>
  </v-app>
</template>


<style lang="scss">
  @import './assets/css/style.css';
</style>
<script>
import AbbiFront from './components/AbbiFront';

export default {
  name: 'App',

  components: {
    AbbiFront,
  },

  data: () => ({
    //
  }),
};
</script>

<template>
  <div class="bg-image">

     <div class="vue-20-card">
       <h2 
          class="number-heading"
          align="right"
          justify="right"
        >
         20
       </h2>
       <h2 
          class="number-heading"
          align="right"
          justify="right"
        >
         20
       </h2>
     </div>   

     <div class="main-card">
       <div class="logo-card"
        align="center"
        justify="center"
       >
         <div class="logo-img">
           <v-img src="../assets/img/logo.png"></v-img>
         </div>
       </div>

      <v-text
       class="text-tagline"
      >
      Confidential & Proprietary
     </v-text>
     </div>

  </div>
</template>


